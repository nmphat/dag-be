import { Injectable } from '@nestjs/common';
import { Concept, Edge } from '@prisma/client';
import { sql } from 'kysely';
import { PrismaService } from '../../db/prisma.service';

@Injectable()
export class EdgeRepository {
  constructor(private prisma: PrismaService) {}

  async create(parentId: string, childId: string): Promise<Edge> {
    return this.prisma.prisma.edge.create({
      data: {
        parent: { connect: { id: parentId } },
        child: { connect: { id: childId } },
      },
    });
  }

  async findByParentAndChild(
    parentId: string,
    childId: string,
  ): Promise<Edge | null> {
    return this.prisma.prisma.edge.findUnique({
      where: {
        parentId_childId: { parentId, childId },
      },
    });
  }

  async findByParent(parentId: string, includeChild = false): Promise<Edge[]> {
    return this.prisma.prisma.edge.findMany({
      where: { parentId },
      include: includeChild ? { child: true } : undefined,
    });
  }

  async findByChild(childId: string, includeParent = false): Promise<Edge[]> {
    return this.prisma.prisma.edge.findMany({
      where: { childId },
      include: includeParent ? { parent: true } : undefined,
    });
  }

  async delete(parentId: string, childId: string): Promise<Edge> {
    return this.prisma.prisma.edge.delete({
      where: {
        parentId_childId: { parentId, childId },
      },
    });
  }

  async getParents(conceptId: string): Promise<Concept[]> {
    const edges = await this.prisma.prisma.edge.findMany({
      where: { childId: conceptId },
      include: { parent: true },
    });
    return edges.map((e) => e.parent as Concept);
  }

  async getChildren(conceptId: string): Promise<Concept[]> {
    const edges = await this.prisma.prisma.edge.findMany({
      where: { parentId: conceptId },
      include: { child: true },
    });
    return edges.map((e) => e.child as Concept);
  }

  async detectCycle(parentId: string, childId: string): Promise<boolean> {
    // Use read replica for cycle detection
    const result = await this.prisma.db
      .read()
      .withRecursive('path', (qb) =>
        qb
          .selectFrom('edges')
          .select(['parent_id', 'child_id'])
          .where('parent_id', '=', childId)
          .unionAll((qb) =>
            qb
              .selectFrom('edges as e')
              .innerJoin('path as p', 'e.parent_id', 'p.child_id')
              .select(['e.parent_id', 'e.child_id']),
          ),
      )
      .selectFrom('path')
      .select(sql<number>`1`.as('exists'))
      .where('child_id', '=', parentId)
      .limit(1)
      .execute();

    return result.length > 0;
  }

  async canReach(fromId: string, toId: string): Promise<boolean> {
    // Check if fromId can reach toId through edges - use read replica
    const result = await this.prisma.db
      .read()
      .withRecursive('path', (qb) =>
        qb
          .selectFrom('edges')
          .select(['parent_id', 'child_id'])
          .where('parent_id', '=', fromId)
          .unionAll((qb) =>
            qb
              .selectFrom('edges as e')
              .innerJoin('path as p', 'e.parent_id', 'p.child_id')
              .select(['e.parent_id', 'e.child_id']),
          ),
      )
      .selectFrom('path')
      .select(sql<number>`1`.as('exists'))
      .where('child_id', '=', toId)
      .limit(1)
      .execute();

    return result.length > 0;
  }
}
