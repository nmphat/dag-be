import { Injectable } from '@nestjs/common';
import { Concept, Prisma, Variant } from '@prisma/client';
import { sql } from 'kysely';
import { PrismaService } from '../../db/prisma.service';

@Injectable()
export class ConceptRepository {
  constructor(private prisma: PrismaService) {}

  // ============================================
  // BASIC CRUD (Delegated to Prisma for simplicity)
  // ============================================

  async create(data: Prisma.ConceptCreateInput): Promise<Concept> {
    return this.prisma.prisma.concept.create({ data });
  }

  async findById(id: string): Promise<Concept | null> {
    return this.prisma.prisma.concept.findUnique({ where: { id } });
  }

  async findMany(params: {
    where?: Prisma.ConceptWhereInput;
    take?: number;
    skip?: number;
    orderBy?: Prisma.ConceptOrderByWithRelationInput[];
  }): Promise<Concept[]> {
    return this.prisma.prisma.concept.findMany(params);
  }

  async count(where?: Prisma.ConceptWhereInput): Promise<number> {
    return this.prisma.prisma.concept.count({ where });
  }

  async update(id: string, data: Prisma.ConceptUpdateInput): Promise<Concept> {
    return this.prisma.prisma.concept.update({
      where: { id },
      data,
    });
  }

  async delete(id: string): Promise<Concept> {
    return this.prisma.prisma.concept.delete({ where: { id } });
  }

  // ============================================
  // VARIANTS
  // ============================================

  async createVariant(conceptId: string, name: string): Promise<Variant> {
    return this.prisma.prisma.variant.create({
      data: { conceptId, name },
    });
  }

  async findVariantsByConceptId(conceptId: string): Promise<Variant[]> {
    return this.prisma.prisma.variant.findMany({ where: { conceptId } });
  }

  async deleteVariantsByConceptId(conceptId: string): Promise<void> {
    await this.prisma.prisma.variant.deleteMany({ where: { conceptId } });
  }

  // ============================================
  // NAVIGATION & DRILL-DOWN (Prisma is good here)
  // ============================================

  /**
   * Get immediate children with pagination.
   * Using Prisma findMany is cleaner here than Raw SQL.
   */
  async findChildren(parentId: string, limit: number, offset: number): Promise<Concept[]> {
    return this.prisma.prisma.concept.findMany({
      where: {
        parentEdges: { some: { parentId } }
      },
      take: limit,
      skip: offset,
      orderBy: [{ level: 'asc' }, { label: 'asc' }],
    });
  }

  async countChildren(parentId: string): Promise<number> {
    return this.prisma.prisma.edge.count({
      where: { parentId }
    });
  }

  async findParents(childId: string): Promise<Concept[]> {
    return this.prisma.prisma.concept.findMany({
      where: {
        childEdges: { some: { childId } }
      }
    });
  }

  // ============================================
  // OBSERVABILITY & STATS
  // ============================================

  async countEdges(): Promise<number> {
    return this.prisma.prisma.edge.count();
  }

  async getMaxDepth(): Promise<number> {
    const result = await this.prisma.prisma.concept.aggregate({
      _max: { level: true }
    });
    return result._max.level || 0;
  }

  // ============================================
  // GRAPH ALGORITHMS (Kysely Power)
  // ============================================

  /**
   * Uses Recursive CTE to find ALL ancestors.
   * Returns a flat list of unique concepts.
   */
  async getAncestors(conceptId: string): Promise<Concept[]> {
    const result = await this.prisma.db
      .read()
      .withRecursive('ancestors', (qb) =>
        qb
          .selectFrom('edges')
          .select(['parent_id', 'child_id'])
          .where('child_id', '=', conceptId)
          .unionAll((qb) =>
            qb
              .selectFrom('edges as e')
              .innerJoin('ancestors as a', 'e.child_id', 'a.parent_id')
              .select(['e.parent_id', 'e.child_id']),
          ),
      )
      .selectFrom('ancestors as a')
      .innerJoin('concepts as c', 'a.parent_id', 'c.id')
      .selectAll('c')
      .distinct() // Handle DAG multi-path duplicates
      .orderBy('c.level', 'asc')
      .execute();

    return result.map(this.mapToPrismaConcept);
  }

  /**
   * Uses Recursive CTE to find ALL descendants.
   */
  async getDescendants(conceptId: string): Promise<Concept[]> {
    const result = await this.prisma.db
      .read()
      .withRecursive('descendants', (qb) =>
        qb
          .selectFrom('edges')
          .select(['parent_id', 'child_id'])
          .where('parent_id', '=', conceptId)
          .unionAll((qb) =>
            qb
              .selectFrom('edges as e')
              .innerJoin('descendants as d', 'e.parent_id', 'd.child_id')
              .select(['e.parent_id', 'e.child_id']),
          ),
      )
      .selectFrom('descendants as d')
      .innerJoin('concepts as c', 'd.child_id', 'c.id')
      .selectAll('c')
      .distinct()
      .execute();

    return result.map(this.mapToPrismaConcept);
  }

  /**
   * DAG PATH FINDER
   * Returns all possible paths from Root -> Target Node.
   * Output: Array of Concept Arrays.
   */
  async getPathsToRoot(conceptId: string): Promise<Concept[][]> {
    // 1. Use CTE to build path strings (e.g., "root_id,mid_id") up to the parent
    const pathResults = await this.prisma.db.read()
      .withRecursive('path_cte', (db) => db
        .selectFrom('edges')
        .select(['parent_id', 'child_id', sql<string>`CAST(parent_id AS CHAR(1000))`.as('path_str')])
        .where('child_id', '=', conceptId)
        .unionAll((db) => db
          .selectFrom('edges as e')
          .innerJoin('path_cte as cte', 'e.child_id', 'cte.parent_id')
          .select([
            'e.parent_id', 
            'e.child_id', 
            sql<string>`CONCAT(e.parent_id, ',', cte.path_str)`.as('path_str')
          ])
        )
      )
      .selectFrom('path_cte')
      .select('path_str')
      // Only get paths that reached a root (no incoming edges, or simplified logic: just take all)
      // For simplicity in a Taxonomy, we just take the constructed paths
      .execute();

    if (pathResults.length === 0) return [];

    // 2. Extract all unique Concept IDs from the paths
    const allPathIds = new Set<string>();
    pathResults.forEach(row => {
      row.path_str.split(',').forEach(id => allPathIds.add(id));
    });
    allPathIds.add(conceptId); // Add the target node itself

    // 3. Fetch all concepts involved in one go
    const concepts = await this.prisma.prisma.concept.findMany({
      where: { id: { in: Array.from(allPathIds) } }
    });
    
    // Create a Lookup Map for O(1) access
    const conceptMap = new Map(concepts.map(c => [c.id, c]));
    const targetNode = conceptMap.get(conceptId);

    if (!targetNode) return [];

    // 4. Reconstruct the arrays
    // path_str is like "Grandparent,Parent". We need [Grandparent, Parent, Target]
    return pathResults.map(row => {
      const ids = row.path_str.split(',');
      const pathObjects = ids
        .map(id => conceptMap.get(id))
        .filter((c): c is Concept => !!c); // Filter out nulls
      
      // The CTE built the path UPWARDS (Target -> Parent -> Root)
      // But the string concatenation was `Parent + , + ChildPath`.
      // So the string is "Root,Parent".
      // We append the Target Node at the end.
      return [...pathObjects, targetNode];
    });
  }

  // Helper to map snake_case Kysely result to camelCase Prisma Concept
  private mapToPrismaConcept(row: any): Concept {
    return {
      id: row.id,
      label: row.label,
      definition: row.definition,
      level: row.level,
      createdAt: row.created_at || row.createdAt,
      updatedAt: row.updated_at || row.updatedAt,
    };
  }
}
