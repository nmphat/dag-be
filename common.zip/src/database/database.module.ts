import { Global, Module } from '@nestjs/common';
import { ConceptRepository, EdgeRepository } from './repositories';

@Global()
@Module({
  providers: [ConceptRepository, EdgeRepository],
  exports: [ConceptRepository, EdgeRepository],
})
export class DatabaseModule {}
