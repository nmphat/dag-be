import {
  Injectable,
  Logger,
  OnModuleDestroy,
  OnModuleInit,
} from '@nestjs/common';
import { PrismaMariaDb } from '@prisma/adapter-mariadb';
import { PrismaClient } from '@prisma/client';
import { readReplicas } from '@prisma/extension-read-replicas';
import { Kysely, MysqlDialect } from 'kysely';
import { createPool, Pool, PoolOptions } from 'mysql2'; // Use standard mysql2 for everything
import { DbRouter } from './db-router';
import type { DB } from './types';

@Injectable()
export class PrismaService implements OnModuleInit, OnModuleDestroy {
  private readonly logger = new Logger(PrismaService.name);

  // Prisma Client (Extended with Replicas)
  public prisma: ReturnType<typeof this.createPrismaExtension>;

  // Kysely Router (Master/Slave logic)
  public db: DbRouter;

  // Store pools to manage lifecycle explicitly
  private readonly masterPool: Pool;
  private readonly slavePools: Pool[] = [];

  // Internal Kysely instance for Master (Write)
  private writeDb: Kysely<DB>;

  constructor() {
    // 1. Common Configuration
    const connectionLimit = parseInt(process.env.DB_CONNECTION_LIMIT || '10');
    const commonConfig: Pick<
      PoolOptions,
      'user' | 'password' | 'database' | 'connectionLimit'
    > = {
      user: process.env.DATABASE_USER || 'root',
      password: process.env.DATABASE_PASSWORD || 'rootpass123',
      database: process.env.DATABASE_NAME || 'dag_db',
      connectionLimit,
    };

    // 2. Initialize Master Pool
    this.masterPool = createPool({
      ...commonConfig,
      host: process.env.DATABASE_HOST || 'localhost',
      port: parseInt(process.env.DATABASE_PORT || '3306'),
    });

    // 3. Initialize Slave Pools (Dynamic Check)
    this.slavePools = [];
    if (process.env.DATABASE_SLAVE1_HOST) {
      this.slavePools.push(
        createPool({
          ...commonConfig,
          host: process.env.DATABASE_SLAVE1_HOST,
          port: parseInt(process.env.DATABASE_SLAVE1_PORT || '3307'),
        }),
      );
    }
    if (process.env.DATABASE_SLAVE2_HOST) {
      this.slavePools.push(
        createPool({
          ...commonConfig,
          host: process.env.DATABASE_SLAVE2_HOST,
          port: parseInt(process.env.DATABASE_SLAVE2_PORT || '3308'),
        }),
      );
    }

    // 4. Setup Kysely (Write) sharing the Master Pool
    this.writeDb = new Kysely<DB>({
      dialect: new MysqlDialect({ pool: this.masterPool }),
      // log: ['query', 'error']
    });

    // 5. Setup DbRouter (Passing Slaves for Kysely Read)
    // Note: DbRouter will create lightweight Kysely instances wrapping these pools
    this.db = new DbRouter(this.writeDb, this.slavePools);

    // 6. Setup Prisma (Extended) sharing ALL Pools
    this.prisma = this.createPrismaExtension(this.masterPool, this.slavePools);
  }

  /**
   * Helper to initialize Prisma with Driver Adapters and Read Replicas
   */
  private createPrismaExtension(masterPool: Pool, slavePools: Pool[]) {
    // Adapter for Master
    // Cast to 'any' to avoid annoying type mismatch between mysql2 versions and prisma adapter
    const masterAdapter = new PrismaMariaDb(masterPool as any);

    const masterClient = new PrismaClient({
      adapter: masterAdapter,
      log: ['error', 'warn'],
    });

    // Adapters for Slaves
    const replicaClients = slavePools.map((pool) => {
      const adapter = new PrismaMariaDb(pool as any);
      return new PrismaClient({
        adapter,
        log: ['error', 'warn'],
      });
    });

    // Extend Master with Read Replicas logic
    return masterClient.$extends(
      readReplicas({
        replicas: replicaClients,
      }),
    );
  }

  async onModuleInit() {
    try {
      // Connect explicitly to ensure pools are ready
      await this.prisma.$connect();
      this.logger.log(
        `✅ Database initialized. Slaves: ${this.slavePools.length}`,
      );
    } catch (error) {
      this.logger.error('❌ Failed to connect to database', error);
      throw error;
    }
  }

  async onModuleDestroy() {
    // 1. Disconnect Prisma High-level client
    // This stops accepting new queries but relies on adapter to close pool
    await this.prisma.$disconnect().catch((e) => console.error(e));

    // 2. Destroy Kysely Instance
    // This is purely for Kysely internal cleanup
    await this.writeDb.destroy().catch((e) => console.error(e));

    // 3. FORCE CLOSE POOLS
    // We explicitly close pools to ensure no hanging connections
    // because we shared them between libraries.
    const allPools = [this.masterPool, ...this.slavePools];

    await Promise.all(
      allPools.map(
        (pool) =>
          new Promise<void>((resolve) => {
            pool.end((err) => {
              if (err) console.error('Error closing pool:', err);
              resolve();
            });
          }),
      ),
    );

    this.logger.log('✅ Database connections closed');
  }
}
