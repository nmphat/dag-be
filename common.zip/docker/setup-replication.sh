#!/bin/bash
# Setup MySQL replication

echo "=========================================="
echo "Setting up MySQL Replication..."
echo "=========================================="

# Wait for MySQL master to be ready
echo "Waiting for MySQL master to be ready..."
sleep 10

# Step 1: Create replication user on Master
echo "Step 1: Creating replication user on master..."
docker exec -i dag-mysql-master mysql -uroot -prootpass123 <<EOF
CREATE USER IF NOT EXISTS 'repl_user'@'%' IDENTIFIED BY 'replpass123';
GRANT REPLICATION SLAVE ON *.* TO 'repl_user'@'%';
FLUSH PRIVILEGES;
SELECT user, host FROM mysql.user WHERE user='repl_user';
EOF

echo ""
echo "Step 2: Configuring Slave 1..."
docker exec -i dag-mysql-slave1 mysql -uroot -prootpass123 <<EOF
STOP SLAVE;
CHANGE MASTER TO
  MASTER_HOST='mysql-master',
  MASTER_USER='repl_user',
  MASTER_PASSWORD='replpass123',
  MASTER_AUTO_POSITION=1;
START SLAVE;
EOF

echo ""
echo "Step 3: Configuring Slave 2..."
docker exec -i dag-mysql-slave2 mysql -uroot -prootpass123 <<EOF
STOP SLAVE;
CHANGE MASTER TO
  MASTER_HOST='mysql-master',
  MASTER_USER='repl_user',
  MASTER_PASSWORD='replpass123',
  MASTER_AUTO_POSITION=1;
START SLAVE;
EOF

echo ""
echo "=========================================="
echo "Replication setup complete!"
echo "=========================================="
echo ""
echo "Checking Slave 1 status..."
docker exec -i dag-mysql-slave1 mysql -uroot -prootpass123 -e "SHOW SLAVE STATUS\G" | grep -E "Slave_IO_Running|Slave_SQL_Running|Seconds_Behind_Master"

echo ""
echo "Checking Slave 2 status..."
docker exec -i dag-mysql-slave2 mysql -uroot -prootpass123 -e "SHOW SLAVE STATUS\G" | grep -E "Slave_IO_Running|Slave_SQL_Running|Seconds_Behind_Master"

echo ""
echo "If both show 'Slave_IO_Running: Yes' and 'Slave_SQL_Running: Yes', replication is working!"
