-- Create replication user
CREATE USER IF NOT EXISTS 'repl_user'@'%' IDENTIFIED BY 'replpass123';
GRANT REPLICATION SLAVE ON *.* TO 'repl_user'@'%';
FLUSH PRIVILEGES;

-- Use the DAG database
USE dag_db;

-- Show master status for verification
SHOW MASTER STATUS;
