import { Client } from '@elastic/elasticsearch';
import { readFileSync } from 'fs';
import { createConnection } from 'mysql2/promise';
import { join } from 'path';

// Load env variables if not already loaded (e.g. via dotenv/config)
// require('dotenv').config();

interface Concept {
  id: string;
  label: string;
  definition: string;
  level: number;
  variants: string[];
}

interface ConceptsData {
  concepts: Concept[];
}

interface EdgesData {
  edges: Array<[string, string]>;
}

async function main() {
  const connection = await createConnection({
    host: process.env.DATABASE_HOST || 'localhost',
    port: parseInt(process.env.DATABASE_PORT || '3306'),
    user: process.env.DATABASE_USER || 'root',
    password: process.env.DATABASE_PASSWORD || 'rootpass123',
    database: process.env.DATABASE_NAME || 'dag_db',
  });

  try {
    console.log('📥 Loading sample data...');

    const conceptsPath = join(__dirname, '../docs/sample-data/concepts.json');
    const edgesPath = join(__dirname, '../docs/sample-data/edges.json');

    // Read full files - OK for sample data, but production might need streaming
    const conceptsData: ConceptsData = JSON.parse(
      readFileSync(conceptsPath, 'utf-8'),
    );
    const edgesData: EdgesData = JSON.parse(readFileSync(edgesPath, 'utf-8'));

    console.log(`Found ${conceptsData.concepts.length} concepts`);
    console.log(`Found ${edgesData.edges.length} edges`);

    console.log('🗑️  Clearing existing data...');
    // Delete in reverse dependency order
    await connection.execute('DELETE FROM edges');
    await connection.execute('DELETE FROM variants');
    await connection.execute('DELETE FROM concepts');

    console.log('📝 Importing concepts & variants...');
    let importedNodes = 0;
    const batchSize = 1000;

    for (let i = 0; i < conceptsData.concepts.length; i += batchSize) {
      const batch = conceptsData.concepts.slice(i, i + batchSize);
      const now = new Date();

      // 1. Prepare Concepts
      const conceptValues = batch.map((c) => [
        c.id,
        c.label,
        c.definition || null,
        c.level,
        now,
        now,
      ]);

      const conceptPlaceholders = batch
        .map(() => '(?, ?, ?, ?, ?, ?)')
        .join(',');
      await connection.execute(
        `INSERT INTO concepts (id, label, definition, level, created_at, updated_at) VALUES ${conceptPlaceholders}`,
        conceptValues.flat(),
      );

      // 2. Prepare Variants (flattened)
      // We need to perform variant insertions per batch as well
      const variantValues: any[] = [];
      for (const c of batch) {
        if (c.variants && c.variants.length > 0) {
          for (const vName of c.variants) {
            variantValues.push(c.id, vName, now);
          }
        }
      }

      if (variantValues.length > 0) {
        const variantCount = variantValues.length / 3;
        // Construct placeholders: (?, ?, ?), (?, ?, ?), ...
        const variantPlaceholders = Array(variantCount)
          .fill('(?, ?, ?)')
          .join(',');

        await connection.execute(
          `INSERT INTO variants (concept_id, name, created_at) VALUES ${variantPlaceholders}`,
          variantValues,
        );
      }

      importedNodes += batch.length;
      console.log(
        `  Imported ${importedNodes}/${conceptsData.concepts.length} concepts`,
      );
    }

    console.log('🔗 Importing edges...');
    let importedEdges = 0;

    for (let i = 0; i < edgesData.edges.length; i += batchSize) {
      const batch = edgesData.edges.slice(i, i + batchSize);
      const now = new Date();
      // Edge tuple is [parent, child]
      const values = batch.map((edge) => [...edge, now]).flat();
      const placeholders = batch.map(() => '(?, ?, ?)').join(',');

      await connection.execute(
        `INSERT IGNORE INTO edges (parent_id, child_id, created_at) VALUES ${placeholders}`,
        values,
      );

      importedEdges += batch.length;
      console.log(
        `  Imported ${importedEdges}/${edgesData.edges.length} edges`,
      );
    }

    console.log('🔍 Indexing to Elasticsearch...');

    const esClient = new Client({
      node: process.env.ELASTICSEARCH_NODE || 'http://localhost:9200',
    });

    // Use same index name as SearchService ('concepts' or env var)
    const indexName = process.env.ES_INDEX_NAME || 'concepts';
    const esExists = await esClient.indices.exists({ index: indexName });

    if (esExists) {
      await esClient.indices.delete({ index: indexName });
    }

    await esClient.indices.create({
      index: indexName,
      settings: {
        number_of_shards: 1,
        number_of_replicas: 0,
        analysis: {
          analyzer: {
            custom_analyzer: {
              type: 'custom',
              tokenizer: 'standard',
              filter: ['lowercase', 'asciifolding'],
            },
          },
        },
      },
      mappings: {
        properties: {
          id: { type: 'keyword' },
          label: {
            type: 'text',
            analyzer: 'custom_analyzer',
            fields: { keyword: { type: 'keyword' } },
          },
          definition: {
            type: 'text',
            analyzer: 'custom_analyzer',
          },
          level: { type: 'integer' },
          variants: {
            type: 'text',
            analyzer: 'custom_analyzer',
          },
        },
      },
    });

    let indexedNodes = 0;
    for (let i = 0; i < conceptsData.concepts.length; i += batchSize) {
      const batch = conceptsData.concepts.slice(i, i + batchSize);
      const operations = batch.flatMap((concept) => [
        { index: { _index: indexName, _id: concept.id } },
        {
          id: concept.id,
          label: concept.label,
          definition: concept.definition,
          level: concept.level,
          variants: concept.variants || [],
        },
      ]);

      await esClient.bulk({ operations, refresh: false });
      indexedNodes += batch.length;
      console.log(
        `  Indexed ${indexedNodes}/${conceptsData.concepts.length} docs to Elasticsearch`,
      );
    }

    // Force refresh after bulk
    await esClient.indices.refresh({ index: indexName });

    console.log('✅ Import completed!');
    console.log(`  Total concepts: ${importedNodes}`);
    console.log(`  Total edges: ${importedEdges}`);
    console.log(`  Elasticsearch indexed: ${indexedNodes}`);
  } catch (error) {
    console.error('❌ Import failed:', error);
    process.exit(1);
  } finally {
    await connection.end();
  }
}

main();
